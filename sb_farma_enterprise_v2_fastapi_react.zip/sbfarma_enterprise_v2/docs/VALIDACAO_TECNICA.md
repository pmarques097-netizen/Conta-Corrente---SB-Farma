# Validação técnica

Executado antes da entrega:

- `python -m compileall backend` concluído sem erro.
- Inicialização do banco local SQLite validada.
- Seed dos tipos de negociação validado.
- Servidor FastAPI iniciado localmente via Uvicorn.
- Endpoints testados com sucesso:
  - `/`
  - `/api/health`
  - `/api/types`
  - `/api/dashboard`

Observação: a conexão com o banco ERP precisa ser configurada na tela **Importar dados** ou por variáveis de ambiente no servidor.
