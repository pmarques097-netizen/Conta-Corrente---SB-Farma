Coloque aqui os scripts SQL de integração com o banco do ERP.

Arquivos esperados:
- ENTRADAS_SB.sql
- VENDAS_SB.sql
