from datetime import datetime
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from sqlalchemy import func
from backend.app.core.db import get_db
from backend.app.models.entities import Negotiation, NegotiationProduct, LedgerEntry, NegotiationType, ApurationCache
from backend.app.api.schemas import NegotiationIn, LedgerIn, ErpConfigIn
from backend.app.services.apuration import recalc_negotiation
from backend.app.services.ledger import ledger_rows, summary as ledger_summary
from backend.app.services.settings import set_value, get_many
from backend.app.services.importer import test_erp_connection, import_sql_to_summary
from backend.app.services.audit import log

api = APIRouter(prefix='/api')

def _neg_to_dict(n: Negotiation) -> dict:
    return {
        'id': n.id, 'code': n.code, 'manufacturer': n.manufacturer, 'supplier': n.supplier,
        'type_name': n.type_name, 'investment_mode': n.investment_mode, 'status': n.status,
        'start_date': n.start_date.isoformat() if n.start_date else '', 'end_date': n.end_date.isoformat() if n.end_date else '',
        'competence': n.competence, 'percent_investment': n.percent_investment,
        'purchase_goal': n.purchase_goal, 'sale_goal_value': n.sale_goal_value,
        'fixed_credit_value': n.fixed_credit_value, 'products_count': len(n.products),
        'condition_notes': n.condition_notes,
    }

@api.get('/health')
def health():
    return {'ok': True, 'service': 'SB Farma Enterprise V2', 'time': datetime.utcnow().isoformat()}

@api.get('/dashboard')
def dashboard(db: Session = Depends(get_db)):
    led = ledger_summary(db)
    negs = db.query(Negotiation).count()
    apu = float(db.query(func.coalesce(func.sum(ApurationCache.investment_value), 0)).scalar() or 0)
    return {'negotiations': negs, 'credits': led['credits'], 'debits': led['debits'], 'balance': led['balance'], 'apuration': apu}

@api.get('/types')
def types(db: Session = Depends(get_db)):
    return [{'id': t.id, 'name': t.name, 'has_products': t.has_products, 'requires_apuration': t.requires_apuration, 'active': t.active} for t in db.query(NegotiationType).filter(NegotiationType.active == True).order_by(NegotiationType.name).all()]

@api.get('/negotiations')
def list_negotiations(db: Session = Depends(get_db)):
    return [_neg_to_dict(n) for n in db.query(Negotiation).order_by(Negotiation.id.desc()).all()]

@api.post('/negotiations')
def create_negotiation(payload: NegotiationIn, db: Session = Depends(get_db)):
    next_id = (db.query(func.coalesce(func.max(Negotiation.id), 0)).scalar() or 0) + 1
    code = f'NEG-{datetime.utcnow().year}-{next_id:06d}'
    n = Negotiation(
        code=code, short_code=code, manufacturer=payload.manufacturer, supplier=payload.supplier,
        type_name=payload.type_name, investment_mode=payload.investment_mode, status=payload.status,
        start_date=payload.start_date, end_date=payload.end_date, competence=payload.competence,
        percent_investment=payload.percent_investment, purchase_goal=payload.purchase_goal,
        sale_goal_value=payload.sale_goal_value, fixed_credit_value=payload.fixed_credit_value,
        condition_notes=payload.condition_notes, created_by=payload.user,
    )
    for p in payload.products:
        n.products.append(NegotiationProduct(**p.model_dump()))
    db.add(n); db.commit(); db.refresh(n)
    recalc_negotiation(db, n.id, payload.user)
    log(db, payload.user, 'Criar negociação', 'negotiation', n.id, n.code)
    return _neg_to_dict(n)

@api.put('/negotiations/{neg_id}')
def update_negotiation(neg_id: int, payload: NegotiationIn, db: Session = Depends(get_db)):
    n = db.get(Negotiation, neg_id)
    if not n: raise HTTPException(404, 'Negociação não encontrada')
    for field in ['manufacturer','supplier','type_name','investment_mode','status','start_date','end_date','competence','percent_investment','purchase_goal','sale_goal_value','fixed_credit_value','condition_notes']:
        setattr(n, field, getattr(payload, field))
    n.products.clear()
    for p in payload.products:
        n.products.append(NegotiationProduct(**p.model_dump()))
    db.commit(); db.refresh(n)
    recalc_negotiation(db, n.id, payload.user)
    log(db, payload.user, 'Alterar negociação', 'negotiation', n.id, n.code)
    return _neg_to_dict(n)

@api.post('/negotiations/{neg_id}/recalculate')
def recalc(neg_id: int, db: Session = Depends(get_db)):
    return recalc_negotiation(db, neg_id)

@api.get('/apuration')
def apuration(db: Session = Depends(get_db)):
    rows = db.query(ApurationCache, Negotiation).join(Negotiation, Negotiation.id == ApurationCache.negotiation_id).order_by(ApurationCache.updated_at.desc()).all()
    return [{
        'negotiation': n.code, 'manufacturer': n.manufacturer, 'supplier': n.supplier,
        'purchase_value': a.purchase_value, 'sale_value': a.sale_value, 'sale_qty': a.sale_qty,
        'investment_value': a.investment_value, 'rule': a.applied_rule, 'updated_at': a.updated_at.isoformat()
    } for a,n in rows]

@api.get('/ledger')
def ledger(entity: str = '', entity_kind: str = '', competence: str = '', status: str = '', db: Session = Depends(get_db)):
    return ledger_rows(db, entity, entity_kind, competence, status)

@api.post('/ledger')
def create_ledger(payload: LedgerIn, db: Session = Depends(get_db)):
    entry = LedgerEntry(**payload.model_dump(exclude={'user'}), created_by=payload.user, origin='Manual')
    db.add(entry); db.commit(); db.refresh(entry)
    log(db, payload.user, 'Criar lançamento financeiro', 'ledger', entry.id, entry.description)
    return {'ok': True, 'id': entry.id}

@api.delete('/ledger/{entry_id}')
def delete_ledger(entry_id: int, user: str = 'Paulo', db: Session = Depends(get_db)):
    entry = db.get(LedgerEntry, entry_id)
    if not entry: raise HTTPException(404, 'Lançamento não encontrado')
    if entry.origin == 'Apuração': raise HTTPException(400, 'Lançamento gerado pela apuração não pode ser excluído diretamente')
    detail = f'{entry.description} | crédito={entry.credit} | débito={entry.debit}'
    db.delete(entry); db.commit()
    log(db, user, 'Excluir lançamento financeiro', 'ledger', entry_id, detail)
    return {'ok': True}

@api.get('/settings/erp')
def get_erp_settings(db: Session = Depends(get_db)):
    cfg = get_many(db, 'erp_')
    if cfg.get('password'):
        cfg['password'] = '********'
    return cfg

@api.post('/settings/erp')
def save_erp_settings(payload: ErpConfigIn, db: Session = Depends(get_db)):
    for k, v in payload.model_dump().items():
        set_value(db, 'erp_' + k, str(v))
    return {'ok': True, 'message': 'Dados do banco salvos.'}

@api.post('/settings/erp/test')
def test_erp(db: Session = Depends(get_db)):
    return test_erp_connection(db)

@api.post('/import/purchases')
def import_purchases(db: Session = Depends(get_db)):
    return import_sql_to_summary(db, 'ENTRADAS_SB.sql', 'compras')

@api.post('/import/sales')
def import_sales(db: Session = Depends(get_db)):
    return import_sql_to_summary(db, 'VENDAS_SB.sql', 'vendas')
