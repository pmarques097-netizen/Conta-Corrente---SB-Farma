from datetime import date
from pydantic import BaseModel, Field

class ProductIn(BaseModel):
    product_name: str
    internal_code: str = ''
    ean: str = ''
    criterion: str = 'Sell Out (Venda)'
    purchase_goal: float = 0
    sale_goal_qty: float = 0
    sale_goal_value: float = 0
    purchase_unit_value: float = 0
    sale_unit_value: float = 0
    purchase_percent: float = 0
    sale_percent: float = 0
    notes: str = ''

class NegotiationIn(BaseModel):
    manufacturer: str = ''
    supplier: str = ''
    type_name: str = 'Sell In'
    investment_mode: str = 'Venda em (Compra)'
    status: str = 'Ativo'
    start_date: date | None = None
    end_date: date | None = None
    competence: str = ''
    percent_investment: float = 0
    purchase_goal: float = 0
    sale_goal_value: float = 0
    fixed_credit_value: float = 0
    condition_notes: str = ''
    products: list[ProductIn] = Field(default_factory=list)
    user: str = 'Paulo'

class LedgerIn(BaseModel):
    negotiation_id: int | None = None
    entity_name: str
    entity_kind: str = 'Fabricante'
    competence: str = ''
    entry_date: date | None = None
    description: str
    document: str = ''
    kind: str = 'Crédito a Receber'
    credit: float = 0
    debit: float = 0
    status: str = 'Em Aberto'
    notes: str = ''
    user: str = 'Paulo'

class ErpConfigIn(BaseModel):
    host: str
    port: int = 5432
    database: str
    user: str
    password: str
