from datetime import datetime, date
from sqlalchemy import String, Date, DateTime, Float, Integer, Boolean, ForeignKey, Text, UniqueConstraint
from sqlalchemy.orm import Mapped, mapped_column, relationship
from backend.app.core.db import Base

class SystemConfig(Base):
    __tablename__ = 'system_config'
    key: Mapped[str] = mapped_column(String(120), primary_key=True)
    value: Mapped[str] = mapped_column(Text, default='')
    updated_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

class NegotiationType(Base):
    __tablename__ = 'negotiation_types'
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    name: Mapped[str] = mapped_column(String(120), unique=True)
    has_products: Mapped[bool] = mapped_column(Boolean, default=False)
    requires_apuration: Mapped[bool] = mapped_column(Boolean, default=True)
    creates_financial_credit: Mapped[bool] = mapped_column(Boolean, default=True)
    uses_ranges: Mapped[bool] = mapped_column(Boolean, default=False)
    active: Mapped[bool] = mapped_column(Boolean, default=True)

class Negotiation(Base):
    __tablename__ = 'negotiations'
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    code: Mapped[str] = mapped_column(String(40), unique=True, index=True)
    short_code: Mapped[str] = mapped_column(String(40), default='')
    manufacturer: Mapped[str] = mapped_column(String(180), default='')
    supplier: Mapped[str] = mapped_column(String(180), default='')
    type_name: Mapped[str] = mapped_column(String(120), default='Sell In')
    investment_mode: Mapped[str] = mapped_column(String(80), default='Venda em (Compra)')
    status: Mapped[str] = mapped_column(String(40), default='Ativo')
    start_date: Mapped[date | None] = mapped_column(Date, nullable=True)
    end_date: Mapped[date | None] = mapped_column(Date, nullable=True)
    competence: Mapped[str] = mapped_column(String(20), default='')
    percent_investment: Mapped[float] = mapped_column(Float, default=0)
    purchase_goal: Mapped[float] = mapped_column(Float, default=0)
    sale_goal_value: Mapped[float] = mapped_column(Float, default=0)
    fixed_credit_value: Mapped[float] = mapped_column(Float, default=0)
    condition_notes: Mapped[str] = mapped_column(Text, default='')
    created_by: Mapped[str] = mapped_column(String(100), default='')
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)
    updated_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    products: Mapped[list['NegotiationProduct']] = relationship(back_populates='negotiation', cascade='all, delete-orphan')
    ledger_entries: Mapped[list['LedgerEntry']] = relationship(back_populates='negotiation')

class NegotiationProduct(Base):
    __tablename__ = 'negotiation_products'
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    negotiation_id: Mapped[int] = mapped_column(ForeignKey('negotiations.id'))
    product_name: Mapped[str] = mapped_column(String(300))
    internal_code: Mapped[str] = mapped_column(String(80), default='')
    ean: Mapped[str] = mapped_column(String(80), default='')
    criterion: Mapped[str] = mapped_column(String(80), default='Sell Out (Venda)')
    purchase_goal: Mapped[float] = mapped_column(Float, default=0)
    sale_goal_qty: Mapped[float] = mapped_column(Float, default=0)
    sale_goal_value: Mapped[float] = mapped_column(Float, default=0)
    purchase_unit_value: Mapped[float] = mapped_column(Float, default=0)
    sale_unit_value: Mapped[float] = mapped_column(Float, default=0)
    purchase_percent: Mapped[float] = mapped_column(Float, default=0)
    sale_percent: Mapped[float] = mapped_column(Float, default=0)
    notes: Mapped[str] = mapped_column(Text, default='')
    negotiation: Mapped['Negotiation'] = relationship(back_populates='products')
    ranges: Mapped[list['ProgressiveRange']] = relationship(back_populates='product', cascade='all, delete-orphan')

class ProgressiveRange(Base):
    __tablename__ = 'progressive_ranges'
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    product_id: Mapped[int | None] = mapped_column(ForeignKey('negotiation_products.id'), nullable=True)
    negotiation_id: Mapped[int | None] = mapped_column(ForeignKey('negotiations.id'), nullable=True)
    threshold_value: Mapped[float] = mapped_column(Float, default=0)
    percent_value: Mapped[float] = mapped_column(Float, default=0)
    product: Mapped['NegotiationProduct'] = relationship(back_populates='ranges')

class PurchaseSummary(Base):
    __tablename__ = 'purchase_summary'
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    competence: Mapped[str] = mapped_column(String(20), default='')
    date_ref: Mapped[date | None] = mapped_column(Date, nullable=True)
    manufacturer: Mapped[str] = mapped_column(String(180), default='')
    supplier: Mapped[str] = mapped_column(String(180), default='')
    internal_code: Mapped[str] = mapped_column(String(80), default='', index=True)
    ean: Mapped[str] = mapped_column(String(80), default='', index=True)
    product_name: Mapped[str] = mapped_column(String(300), default='')
    quantity: Mapped[float] = mapped_column(Float, default=0)
    value: Mapped[float] = mapped_column(Float, default=0)

class SaleSummary(Base):
    __tablename__ = 'sale_summary'
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    competence: Mapped[str] = mapped_column(String(20), default='')
    date_ref: Mapped[date | None] = mapped_column(Date, nullable=True)
    internal_code: Mapped[str] = mapped_column(String(80), default='', index=True)
    ean: Mapped[str] = mapped_column(String(80), default='', index=True)
    product_name: Mapped[str] = mapped_column(String(300), default='')
    quantity: Mapped[float] = mapped_column(Float, default=0)
    value: Mapped[float] = mapped_column(Float, default=0)

class ApurationCache(Base):
    __tablename__ = 'apuration_cache'
    __table_args__ = (UniqueConstraint('negotiation_id', 'product_id', name='uq_apuration_neg_product'),)
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    negotiation_id: Mapped[int] = mapped_column(Integer, index=True)
    product_id: Mapped[int | None] = mapped_column(Integer, nullable=True)
    purchase_value: Mapped[float] = mapped_column(Float, default=0)
    sale_value: Mapped[float] = mapped_column(Float, default=0)
    sale_qty: Mapped[float] = mapped_column(Float, default=0)
    investment_value: Mapped[float] = mapped_column(Float, default=0)
    investment_percent: Mapped[float] = mapped_column(Float, default=0)
    applied_rule: Mapped[str] = mapped_column(String(160), default='')
    updated_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)

class LedgerEntry(Base):
    __tablename__ = 'ledger_entries'
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    negotiation_id: Mapped[int | None] = mapped_column(ForeignKey('negotiations.id'), nullable=True)
    entity_name: Mapped[str] = mapped_column(String(180), default='')
    entity_kind: Mapped[str] = mapped_column(String(40), default='Fabricante')
    competence: Mapped[str] = mapped_column(String(20), default='')
    entry_date: Mapped[date | None] = mapped_column(Date, nullable=True)
    description: Mapped[str] = mapped_column(String(300), default='')
    document: Mapped[str] = mapped_column(String(120), default='')
    kind: Mapped[str] = mapped_column(String(40), default='Crédito a Receber')
    credit: Mapped[float] = mapped_column(Float, default=0)
    debit: Mapped[float] = mapped_column(Float, default=0)
    status: Mapped[str] = mapped_column(String(40), default='Em Aberto')
    origin: Mapped[str] = mapped_column(String(40), default='Manual')
    notes: Mapped[str] = mapped_column(Text, default='')
    created_by: Mapped[str] = mapped_column(String(100), default='')
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)
    negotiation: Mapped['Negotiation'] = relationship(back_populates='ledger_entries')

class AuditLog(Base):
    __tablename__ = 'audit_logs'
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    user: Mapped[str] = mapped_column(String(100), default='')
    action: Mapped[str] = mapped_column(String(120), default='')
    entity: Mapped[str] = mapped_column(String(120), default='')
    entity_id: Mapped[str] = mapped_column(String(80), default='')
    detail: Mapped[str] = mapped_column(Text, default='')
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)
