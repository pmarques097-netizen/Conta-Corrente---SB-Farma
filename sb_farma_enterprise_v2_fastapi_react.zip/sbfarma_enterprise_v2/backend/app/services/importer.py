from pathlib import Path
from datetime import datetime, date
import pandas as pd
import psycopg
from sqlalchemy.orm import Session
from backend.app.models.entities import PurchaseSummary, SaleSummary
from backend.app.services.settings import get_many

ROOT = Path(__file__).resolve().parents[3]
SQL_DIR = ROOT / 'sql'

def _erp_conn_params(db: Session) -> dict:
    cfg = get_many(db, 'erp_')
    return {
        'host': cfg.get('host', ''),
        'port': int(cfg.get('port', '5432') or 5432),
        'dbname': cfg.get('database', ''),
        'user': cfg.get('user', ''),
        'password': cfg.get('password', ''),
        'connect_timeout': 15,
    }

def test_erp_connection(db: Session) -> dict:
    params = _erp_conn_params(db)
    missing = [k for k in ('host','dbname','user','password') if not params.get(k)]
    if missing:
        return {'ok': False, 'message': 'Preencha: ' + ', '.join(missing)}
    try:
        with psycopg.connect(**params) as conn:
            with conn.cursor() as cur:
                cur.execute('select 1')
                cur.fetchone()
        return {'ok': True, 'message': 'Conexão realizada com sucesso.'}
    except Exception as e:
        return {'ok': False, 'message': str(e)}

def _read_sql_file(name: str) -> str:
    path = SQL_DIR / name
    if not path.exists():
        raise FileNotFoundError(f'Script não encontrado: {path}')
    return path.read_text(encoding='utf-8', errors='ignore')

def _normalize_df(df: pd.DataFrame) -> pd.DataFrame:
    df.columns = [str(c).strip().lower().replace(' ', '_') for c in df.columns]
    return df

def _to_date(v):
    if pd.isna(v):
        return None
    try:
        return pd.to_datetime(v).date()
    except Exception:
        return None

def import_sql_to_summary(db: Session, script_name: str, target: str, replace_period: bool = False) -> dict:
    params = _erp_conn_params(db)
    sql = _read_sql_file(script_name)
    with psycopg.connect(**params) as conn:
        df = pd.read_sql(sql, conn)
    df = _normalize_df(df)
    count = 0
    value_total = 0.0
    if target == 'compras':
        # remove all summary for simplicity; production can do period delete
        db.query(PurchaseSummary).delete()
        for _, r in df.iterrows():
            value = float(r.get('compra_base', r.get('valor_nf_total', r.get('valor_total', 0))) or 0)
            qty = float(r.get('qtd_nf', r.get('quantidade', 0)) or 0)
            item = PurchaseSummary(
                competence=str(r.get('competencia','')),
                date_ref=_to_date(r.get('data_apuracao', r.get('datahoraentrada', r.get('data_emissao')))),
                manufacturer=str(r.get('fabricante', r.get('laboratorio','')) or ''),
                supplier=str(r.get('distribuidor', r.get('fornecedor','')) or ''),
                internal_code=str(r.get('cod_interno', r.get('codigo_interno','')) or ''),
                ean=str(r.get('codigobarras', r.get('ean','')) or ''),
                product_name=str(r.get('produto', r.get('descricao', r.get('descricao_embalagem',''))) or ''),
                quantity=qty,
                value=value,
            )
            db.add(item); count += 1; value_total += value
    else:
        db.query(SaleSummary).delete()
        for _, r in df.iterrows():
            value = float(r.get('valor_vendido', r.get('valortotal', r.get('valor_total', 0))) or 0)
            qty = float(r.get('quantidade', r.get('qtd_mov', 0)) or 0)
            item = SaleSummary(
                competence=str(r.get('competencia','')),
                date_ref=_to_date(r.get('datahora_venda_final', r.get('datahora', r.get('data')))),
                internal_code=str(r.get('cod_interno', r.get('codigo_interno','')) or ''),
                ean=str(r.get('codigobarras', r.get('ean','')) or ''),
                product_name=str(r.get('produto', r.get('descricao','')) or ''),
                quantity=qty,
                value=value,
            )
            db.add(item); count += 1; value_total += value
    db.commit()
    return {'ok': True, 'records': count, 'value_total': value_total, 'target': target}
