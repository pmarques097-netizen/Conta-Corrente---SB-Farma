from datetime import datetime
from sqlalchemy.orm import Session
from sqlalchemy import func, and_
from backend.app.models.entities import Negotiation, NegotiationProduct, PurchaseSummary, SaleSummary, ApurationCache, LedgerEntry

def _between_dates(model, start, end):
    filters = []
    if start:
        filters.append(model.date_ref >= start)
    if end:
        filters.append(model.date_ref <= end)
    return filters

def _best_progressive_percent(ranges, realized_value: float, default_percent: float) -> tuple[float, str]:
    if not ranges:
        return default_percent or 0, 'Percentual padrão'
    applicable = [r for r in ranges if realized_value >= (r.threshold_value or 0)]
    if not applicable:
        return 0, 'Nenhuma faixa atingida'
    best = max(applicable, key=lambda r: r.threshold_value or 0)
    return best.percent_value or 0, f'Faixa {best.threshold_value:,.2f} -> {best.percent_value:.2f}%'

def recalc_negotiation(db: Session, neg_id: int, user: str = 'Sistema') -> dict:
    neg = db.get(Negotiation, neg_id)
    if not neg:
        return {'ok': False, 'message': 'Negociação não encontrada'}

    db.query(ApurationCache).filter(ApurationCache.negotiation_id == neg.id).delete()

    total_invest = 0.0
    total_purchase = 0.0
    total_sale = 0.0

    products = neg.products or []
    if products:
        for p in products:
            purchase_q = db.query(func.coalesce(func.sum(PurchaseSummary.value), 0)).filter(*_between_dates(PurchaseSummary, neg.start_date, neg.end_date))
            sale_q = db.query(
                func.coalesce(func.sum(SaleSummary.value), 0),
                func.coalesce(func.sum(SaleSummary.quantity), 0)
            ).filter(*_between_dates(SaleSummary, neg.start_date, neg.end_date))
            if p.internal_code:
                purchase_q = purchase_q.filter(PurchaseSummary.internal_code == p.internal_code)
                sale_q = sale_q.filter(SaleSummary.internal_code == p.internal_code)
            elif p.ean:
                purchase_q = purchase_q.filter(PurchaseSummary.ean == p.ean)
                sale_q = sale_q.filter(SaleSummary.ean == p.ean)
            else:
                purchase_q = purchase_q.filter(PurchaseSummary.product_name == p.product_name)
                sale_q = sale_q.filter(SaleSummary.product_name == p.product_name)
            purchase_value = float(purchase_q.scalar() or 0)
            sale_value, sale_qty = sale_q.one()
            sale_value = float(sale_value or 0)
            sale_qty = float(sale_qty or 0)
            percent, rule = _best_progressive_percent(p.ranges, purchase_value if 'compra' in p.criterion.lower() else sale_value, p.purchase_percent or p.sale_percent)
            invest = 0.0
            if 'compra' in p.criterion.lower():
                invest += purchase_value * (percent / 100.0)
                invest += sale_qty * (p.purchase_unit_value or 0)
            if 'venda' in p.criterion.lower() or 'esgotado' in p.criterion.lower():
                invest += sale_value * ((p.sale_percent or 0) / 100.0)
                invest += sale_qty * (p.sale_unit_value or 0)
            total_invest += invest
            total_purchase += purchase_value
            total_sale += sale_value
            db.add(ApurationCache(
                negotiation_id=neg.id, product_id=p.id, purchase_value=purchase_value, sale_value=sale_value,
                sale_qty=sale_qty, investment_value=invest, investment_percent=percent, applied_rule=rule,
                updated_at=datetime.utcnow()
            ))
    else:
        purchase_q = db.query(func.coalesce(func.sum(PurchaseSummary.value), 0)).filter(*_between_dates(PurchaseSummary, neg.start_date, neg.end_date))
        if neg.manufacturer:
            purchase_q = purchase_q.filter(PurchaseSummary.manufacturer == neg.manufacturer)
        if neg.supplier:
            purchase_q = purchase_q.filter(PurchaseSummary.supplier == neg.supplier)
        purchase_value = float(purchase_q.scalar() or 0)
        percent, rule = _best_progressive_percent([], purchase_value, neg.percent_investment)
        invest = neg.fixed_credit_value or (purchase_value * (percent / 100.0))
        total_invest = invest
        total_purchase = purchase_value
        db.add(ApurationCache(
            negotiation_id=neg.id, product_id=None, purchase_value=purchase_value, sale_value=0, sale_qty=0,
            investment_value=invest, investment_percent=percent, applied_rule=rule, updated_at=datetime.utcnow()
        ))

    # crédito financeiro único por negociação/apuração
    entity = neg.manufacturer or neg.supplier or 'Sem entidade'
    ledger = db.query(LedgerEntry).filter(LedgerEntry.negotiation_id == neg.id, LedgerEntry.origin == 'Apuração').first()
    if total_invest > 0:
        if ledger is None:
            ledger = LedgerEntry(negotiation_id=neg.id, origin='Apuração', created_by=user)
            db.add(ledger)
        ledger.entity_name = entity
        ledger.entity_kind = 'Fabricante' if neg.manufacturer else 'Fornecedor'
        ledger.competence = neg.competence or (neg.start_date.strftime('%m/%Y') if neg.start_date else '')
        ledger.entry_date = neg.end_date or neg.start_date
        ledger.description = f'Crédito apurado - {neg.code}'
        ledger.document = neg.code
        ledger.kind = 'Crédito a Receber'
        ledger.credit = total_invest
        ledger.debit = 0
        ledger.status = 'Em Aberto'
    db.commit()
    return {'ok': True, 'negotiation': neg.code, 'purchase_value': total_purchase, 'sale_value': total_sale, 'investment_value': total_invest}
