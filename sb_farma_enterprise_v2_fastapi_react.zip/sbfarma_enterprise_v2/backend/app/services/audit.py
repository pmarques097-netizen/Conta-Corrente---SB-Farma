from sqlalchemy.orm import Session
from backend.app.models.entities import AuditLog

def log(db: Session, user: str, action: str, entity: str, entity_id: str = '', detail: str = ''):
    db.add(AuditLog(user=user or 'Sistema', action=action, entity=entity, entity_id=str(entity_id or ''), detail=detail or ''))
    db.commit()
