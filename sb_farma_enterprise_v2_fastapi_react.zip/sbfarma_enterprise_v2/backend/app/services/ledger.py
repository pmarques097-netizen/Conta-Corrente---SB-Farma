from itertools import accumulate
from sqlalchemy.orm import Session
from sqlalchemy import func
from backend.app.models.entities import LedgerEntry, Negotiation

def ledger_rows(db: Session, entity: str = '', entity_kind: str = '', competence: str = '', status: str = '') -> list[dict]:
    q = db.query(LedgerEntry)
    if entity:
        q = q.filter(LedgerEntry.entity_name == entity)
    if entity_kind:
        q = q.filter(LedgerEntry.entity_kind == entity_kind)
    if competence:
        q = q.filter(LedgerEntry.competence == competence)
    if status:
        q = q.filter(LedgerEntry.status == status)
    rows = q.order_by(LedgerEntry.entry_date.asc().nulls_last(), LedgerEntry.id.asc()).all()
    out = []
    balance = 0.0
    for r in rows:
        balance += (r.credit or 0) - (r.debit or 0)
        out.append({
            'id': r.id, 'date': r.entry_date.isoformat() if r.entry_date else '', 'competence': r.competence,
            'entity_name': r.entity_name, 'entity_kind': r.entity_kind, 'description': r.description,
            'document': r.document, 'negotiation': r.negotiation.code if r.negotiation else 'AVULSO',
            'kind': r.kind, 'credit': r.credit, 'debit': r.debit, 'balance': balance, 'status': r.status,
            'origin': r.origin, 'notes': r.notes, 'created_by': r.created_by,
        })
    return out

def summary(db: Session) -> dict:
    credit = float(db.query(func.coalesce(func.sum(LedgerEntry.credit), 0)).scalar() or 0)
    debit = float(db.query(func.coalesce(func.sum(LedgerEntry.debit), 0)).scalar() or 0)
    return {'credits': credit, 'debits': debit, 'balance': credit - debit, 'open': credit - debit}
