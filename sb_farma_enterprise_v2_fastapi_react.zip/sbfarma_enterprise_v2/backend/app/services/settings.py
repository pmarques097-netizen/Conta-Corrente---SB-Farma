from sqlalchemy.orm import Session
from backend.app.models.entities import SystemConfig

def set_value(db: Session, key: str, value: str):
    row = db.get(SystemConfig, key)
    if row:
        row.value = value or ''
    else:
        row = SystemConfig(key=key, value=value or '')
        db.add(row)
    db.commit()
    return row

def get_value(db: Session, key: str, default: str = '') -> str:
    row = db.get(SystemConfig, key)
    return row.value if row else default

def get_many(db: Session, prefix: str) -> dict:
    rows = db.query(SystemConfig).filter(SystemConfig.key.like(f'{prefix}%')).all()
    return {r.key.replace(prefix, ''): r.value for r in rows}
