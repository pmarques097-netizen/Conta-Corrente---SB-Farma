from sqlalchemy.orm import Session
from backend.app.models.entities import NegotiationType

DEFAULT_TYPES = [
    ('Sell In', False, True, True, True),
    ('Sell Out', True, True, True, False),
    ('Híbrida', True, True, True, True),
    ('Trade Marketing', False, False, True, False),
    ('Verba Comercial', False, False, True, False),
    ('Bonificação Financeira', False, False, True, False),
    ('Incentivo', False, False, True, False),
    ('Acordo Comercial', False, False, True, False),
    ('Campanha', False, False, True, False),
    ('Evento', False, False, True, False),
    ('Mídia / Digital', False, False, True, False),
    ('Contrato', False, False, True, False),
]

def seed(db: Session):
    if db.query(NegotiationType).count() == 0:
        for name, has_products, requires_apuration, creates_financial_credit, uses_ranges in DEFAULT_TYPES:
            db.add(NegotiationType(
                name=name, has_products=has_products, requires_apuration=requires_apuration,
                creates_financial_credit=creates_financial_credit, uses_ranges=uses_ranges
            ))
        db.commit()
