from pathlib import Path
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from backend.app.core.db import init_db, SessionLocal
from backend.app.services.bootstrap import seed
from backend.app.api.routes import api

ROOT = Path(__file__).resolve().parents[2]
FRONTEND = ROOT / 'frontend'

app = FastAPI(title='SB Farma Enterprise V2', version='2.0.0')
app.add_middleware(
    CORSMiddleware,
    allow_origins=['*'], allow_credentials=True, allow_methods=['*'], allow_headers=['*']
)
app.include_router(api)

@app.on_event('startup')
def startup():
    init_db()
    db = SessionLocal()
    try:
        seed(db)
    finally:
        db.close()

app.mount('/static', StaticFiles(directory=str(FRONTEND)), name='static')

@app.get('/')
def index():
    return FileResponse(str(FRONTEND / 'index.html'))
